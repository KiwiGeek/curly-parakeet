﻿Public Class YearInfo
    Public Property GregYear As String
    Public Property JuliYear As String
    Public Property HebYear As Integer
    Public Property Tishri1GregOldStyle As String
    Public Property Tishri1JuliOldStyle As String
    Public Property PentecostGregOldStyle As String
    Public Property Sivan6GregOldStyle As String
    Public Property Tishri1GregNewStyle As String
    Public Property Tishri1JuliNewStyle As String
    Public Property PentecostGregNewStyle As String
    Public Property Sivan6GregNewStyle As String

    Public Property SummerStartsFixed As String
    Public Property SummerStartsDate As String
    Public Property SummerStartsTime As String

    Public Property PentecostGregOldStyleSunsetStartFixed As String
    Public Property PentecostGregOldStyleSunsetEndfixed As String
    Public Property PentecostGregOldStyleSunsetStartDate As String
    Public Property PentecostGregOldStyleSunsetEndDate As String
    Public Property PentecostGregOldStyleSunsetStartTime As String
    Public Property PentecostGregOldStyleSunsetEndTime As String

    Public Property Sivan6GregOldStyleSunsetStartFixed As String
    Public Property Sivan6GregOldStyleSunsetEndfixed As String
    Public Property Sivan6GregOldStyleSunsetStartDate As String
    Public Property Sivan6GregOldStyleSunsetEndDate As String
    Public Property Sivan6GregOldStyleSunsetStartTime As String
    Public Property Sivan6GregOldStyleSunsetEndTime As String

    Public Property PentecostGregNewStyleSunsetStartFixed As String
    Public Property PentecostGregNewStyleSunsetEndfixed As String
    Public Property PentecostGregNewStyleSunsetStartDate As String
    Public Property PentecostGregNewStyleSunsetEndDate As String
    Public Property PentecostGregNewStyleSunsetStartTime As String
    Public Property PentecostGregNewStyleSunsetEndTime As String

    Public Property Sivan6GregNewStyleSunsetStartFixed As String
    Public Property Sivan6GregNewStyleSunsetEndfixed As String
    Public Property Sivan6GregNewStyleSunsetStartDate As String
    Public Property Sivan6GregNewStyleSunsetEndDate As String
    Public Property Sivan6GregNewStyleSunsetStartTime As String
    Public Property Sivan6GregNewStyleSunsetEndTime As String


End Class
